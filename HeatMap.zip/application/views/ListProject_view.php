
 <div class="container">
 <div class="row" style=" background-color: whitesmoke;">
  <div class="col">*</div>
  <div class="col-10">
		    <div class="container-fluid">     
		    <div class="row" style="padding: 20px;">
		      <div class="col-sm-9"><b style="font-size: 25px;">List Project</b></div>
		      <div class="col-sm-3">Projects / List Project</div>
		    </div>
			
			  <table class="table table-striped">
			    <thead>
			      <tr>
			        <th>#</th>
			        <th>Title</th>
			        <th>Date</th>
					<th>Actions</th>
			      </tr>
			    </thead>
			    <tbody>
					<?php foreach ($todo_list as $item):?>
					      <tr>
						    <td><?php echo $item['ProjectID'];?></td>
					        <td><?php echo $item['ProjectTitle'];?></td>
					        <td><?php echo $item['DateTimeAdd'];?></td>
					        <td>
									<div class="btn-group">
									  <a href="<?php echo site_url('ViewProject/index/' . $item['ProjectID']);?>" type="button" class="btn btn-primary"><i class="fa fa-eye" style="font-size:24px"></i></a>
									  <a href='<?php echo site_url('EditProject/index/' . $item['ProjectID']);?>' type="button" class="btn btn-warning"><i class="fa fa-edit" style="font-size:24px"></i></a>
									  <a href='<?php echo site_url('ListProject/delete/' . $item['ProjectID']);?>' type="button" class="btn bg-danger"><i class="fa fa-trash-o" style="font-size:24px"></i></a>
									</div>
							</td>
					      </tr>
			        <?php endforeach;?>

			    </tbody>
			  </table>
  
			<br>
			<Br>
		  </div>
  </div>
  <div class="col">*</div>
</div>
</div>

 