
 <div class="container">
 <div class="row" style=" background-color: whitesmoke;">
  <div class="col">*</div>
  <div class="col-10">
		    <div class="container-fluid">     
		    <div class="row" style="padding: 20px;">
		      <div class="col-sm-9"><b style="font-size: 25px;">Edit Project</b></div>
		      <div class="col-sm-3">Projects / Edit Project</div>
		    </div>
			
<form style="background-color: white;padding: 20px;"  action="<?php echo site_url('EditProject/Edit');?>" method="post">
  <div class="form-group row">
    <label for="inputEmail3" class="col-sm-3 col-form-label">Company</label>
    <div class="col-sm-9">
      <label id="inputEmail3" class="col-sm-2 col-form-label"><?php echo $this->session->userdata('userCompanyName');?></label>
    </div>
  </div>
  
  <br>
  
  <input type="hidden"  id="Projectid" name="Projectid" value="<?php echo $todo_list[0]['ProjectID'];?>">
  
  
      <br>
  
  <div class="form-group row">
    <label for="ProjectTitle" class="col-sm-3 col-form-label">Project title</label>
    <div class="col-sm-9">
      <input type="text" class="form-control" id="ProjectTitle" name="ProjectTitle" placeholder="Enter project title" value="<?php echo $todo_list[0]['ProjectTitle'];?>">
    </div>
  </div>
  
  
      <br>
	  
    <div class="form-group row">
	    <label for="ProjectDevices" class="col-sm-3 col-form-label">Project devices ID +</label>
    <div class="col-sm-9">
		  <div class="input-group mb-3">
		    <input type="text" class="form-control" id="ProjectDevices" name="ProjectDevices" placeholder="Enter devices id"   value="<?php echo $todo_list[0]['ProjectDeviceID'];?>">
		    <div class="input-group-append">
		      <input type="color" class="form-control" id="ProjectDevicesColor" name="ProjectDevicesColor" list="presets" value="<?php echo $todo_list[0]['ProjectDeviceColor'];?>" style="min-width: 100px;height: 100%;">
			  <datalist id="presets">
				  <option value="#cccccc">Grey</option>
				  <option value="#ffffff">White</option>
				  <option value="#6699cc">Blue</option>
				  <option value="#ff0000">#ff0000</option>
				  <option value="#0000ff">#0000ff</option>
				  <option value="#00ff00">#00ff00</option>
				  <option value="#ffff00">#ffff00</option>
				  <option value="#00ffff">#00ffff</option>
			</datalist>
		     </div>
		    <div class="input-group-append">
			    <select  class="form-control" id="ProjectDeviceType" name="ProjectDeviceType">
			      <option value="Human"  selected>Human</option>
			      <option value="Robot">Robot</option>
			      <option value="L">L</option>
			    </select>
		     </div>
		  </div>
    </div>
  </div>
    <br>
	
	  <div class="form-group row">
    <label for="ProjectDevices" class="col-sm-3 col-form-label">Unit (px)</label>
    <div class="col-sm-9">
      <input type="text" class="form-control" id="ProjectUnit" name="ProjectUnit"  placeholder="Enter project unit"  value="<?php echo $todo_list[0]['Unit'];?>">
    </div>
  </div>
  
    <br>
	
	  <div class="form-group row">
    <label for="ProjectDevices" class="col-sm-3 col-form-label">Project background images</label>
    <div class="col-sm-9">
	<img src="<?php echo $todo_list[0]['ProjectBackgroundImage'];?>" />
	<br>
	  <input type="file" class="form-control" id="ImageFile" name="ImageFile" onchange="encodeImageFileAsURL(this)">
	  <input type="hidden" id="ImageFileB64" name="ImageFileB64" value="<?php echo $todo_list[0]['ProjectBackgroundImage'];?>">
    </div>
  </div>
  
    <br>
	
	  <div class="form-group row">
    <div class="col-sm-6"  style="text-align: left;">
      <a href="<?php echo site_url('ListProject');?>" class="btn btn-primary">Back List</a>
    </div>
	    <div class="col-sm-6" style="text-align: right;">
      <button type="submit" class="btn btn-primary">Submit</button>
    </div>
  </div>
	

</form>
			<br>
			<Br>
		  </div>
  </div>
  <div class="col">*</div>
</div>
</div>

    <script type="text/javascript">
	
	$('#ProjectDeviceType').find('option[value=<?php echo $todo_list[0]['ProjectDeviceType'];?>]').attr('selected','selected');
	
        function encodeImageFileAsURL(element) {
  var file = element.files[0];
  console.log(file);
  var reader = new FileReader();
  reader.onloadend = function() {
    console.log('RESULT', reader.result)
	document.getElementById("ImageFileB64").value=reader.result;
  }
  reader.readAsDataURL(file);
}
    </script>
 