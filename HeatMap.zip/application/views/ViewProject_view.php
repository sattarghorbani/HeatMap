
 <div class="container">
 <div class="row" style=" background-color: whitesmoke;">
  <div class="col">*</div>
  <div class="col-10">
		    <div class="container-fluid">     
		    <div class="row" style="padding: 20px;">
		      <div class="col-sm-9"><b style="font-size: 25px;">The Project</b></div>
		      <div class="col-sm-3">Projects / View Project</div>
		    </div>
			

  <div class="form-group row">
    <label for="inputEmail3" class="col-sm-3 col-form-label">Company</label>
    <div class="col-sm-9">
      <label id="inputEmail3" class="col-sm-2 col-form-label">"<?php echo $this->session->userdata('userCompanyName');?>"</label>
    </div>
  </div>
  
  <br>
  
  <div class="form-group row">
    <label for="ProjectTitle" class="col-sm-3 col-form-label">Project title</label>
    <div class="col-sm-9">
      <input type="text" class="form-control" readonly id="ProjectTitle" name="ProjectTitle" value="<?php echo $todo_list[0]['ProjectTitle'];?>">
    </div>
  </div>
  
  
      <br>
	  
    <div class="form-group row">
	    <label for="ProjectDevices" class="col-sm-3 col-form-label">Project devices ID +</label>
    <div class="col-sm-9">
		  <div class="input-group mb-3">
		    <input type="text" readonly class="form-control" id="ProjectDevices" name="ProjectDevices"  value="<?php echo $todo_list[0]['ProjectDeviceID'];?>">
		    <div class="input-group-append">
		      <input type="color" readonly disabled class="form-control" id="ProjectDevicesColor" name="ProjectDevicesColor"   value="<?php echo $todo_list[0]['ProjectDeviceColor'];?>" style="min-width: 100px;height: 100%;">
		     </div>
		    <div class="input-group-append">
					<input type="text" readonly class="form-control" id="ProjectDeviceType" name="ProjectDeviceType"   value="<?php echo $todo_list[0]['ProjectDeviceType'];?>" style="min-width: 100px;height: 100%;">
		     </div>
		  </div>
    </div>
  </div>
    <br>
	
	  <div class="form-group row">
    <label for="ProjectDevices" class="col-sm-3 col-form-label">Unit (px)</label>
    <div class="col-sm-9">
      <input type="text" readonly class="form-control" id="ProjectUnit" name="ProjectUnit"   value="<?php echo $todo_list[0]['Unit'];?>">
    </div>
  </div>
  
    <br>
	
	  <div class="form-group row">
    <label for="ProjectDevices" class="col-sm-3 col-form-label">Project background images</label>
    <div class="col-sm-9">
	  <img src="<?php echo $todo_list[0]['ProjectBackgroundImage'];?>" />
    </div>
  </div>
  
    <br>
	
  <div class="form-group row">
    <div class="col-sm-6"  style="text-align: left;">
      <a href="<?php echo site_url('ListProject');?>" class="btn btn-primary">Back List</a>
    </div>
	    <div class="col-sm-6" style="text-align: right;">
      <a href="<?php echo site_url('ExportProject/index/' . $todo_list[0]['ProjectID']);?>" class="btn btn-primary">Export</a>
    </div>
  </div>

			<br>
			<Br>
		  </div>
  </div>
  <div class="col">*</div>
</div>
</div>

 