
 <div class="container">
 <div class="row" style=" background-color: whitesmoke;">
  <div class="col">*</div>
  <div class="col-10">
		    <div class="container-fluid">     
		    <div class="row" style="padding: 20px;">
		      <div class="col-sm-9"><b style="font-size: 25px;">Export</b></div>
		      <div class="col-sm-3">Projects / Export Project</div>
		    </div>
			
<form style="background-color: white;padding: 20px;"  action="<?php echo site_url('ExportProject/SaveNewExport');?>" method="post">
  <div class="form-group row">
    <label   class="col-sm-3 col-form-label">Company</label>
    <div class="col-sm-9">
      <label   class="col-sm-6 col-form-label"><?php echo $this->session->userdata('userCompanyName');?></label>
	  <br>
	  <label class="col-sm-12 col-form-label">Last Update (From   <?php echo $todo_list[0]['DateTimeAdd'];?>  TO ) </label>
    </div>
  </div>
  
  <br>
  
  <input type="hidden" class="form-control" id="ProjectID" name="ProjectID" value="<?php echo $todo_list[0]['ProjectID'];?>">
  
  	  <div class="form-group row">
    <label for="ProjectDevices" class="col-sm-3 col-form-label">Log File</label>
    <div class="col-sm-9">
	  <input type="file" class="form-control" id="LogFile" name="LogFile" onchange="encodeLogFileAsURL(this)">
	  	  <input type="hidden" class="form-control" id="FileRead" name="FileRead" >
    </div>
  </div>
  
    <br>
	
	 <div class="form-group row">
	 <label   class="col-sm-3 col-form-label">Select Type</label>
			 <div class="col-sm-9">
			  <div class="form-check form-check-inline">
			  <input class="form-check-input" type="radio" name="ExportSelectionType" id="Spaghetti" value="Spaghetti">
			  <label class="form-check-label" for="Spaghetti">
			    Spaghetti
			  </label>
			</div>
			<div class="form-check form-check-inline">
				  <input class="form-check-input" type="radio" name="ExportSelectionType" id="Heatmap"  value="Heatmap" checked>
				  <label class="form-check-label" for="Heatmap">
				    Heatmap
				  </label>
			</div>		
	</div>
	</div>
	
    <br>
	
	
	 <div class="form-group row">
	 <label   class="col-sm-3 col-form-label">Select Devices</label>
			 <div class="col-sm-9" id="chkSelectDevices">

			</div>
			  <input type="hidden" class="form-control" id="SelectDevices" name="SelectDevices">
	</div>
	
    <br>
  
	 
	
<div class="form-group row">
	    <label for="ProjectDevices" class="col-sm-3 col-form-label">Choose Date</label>
		  <div class="col">
				<select class="form-control ChangeByItemSelection" id="DateFrom" name="DateFrom">
				</select>
		  </div>
		  <div class="col">
			 	<select class="form-control ChangeByItemSelection" id="DateTo" name="DateTo">
				</select>
		  </div>
</div>

    <br>
	
	  <div class="form-group row">
    <label for="ProjectDevices" class="col-sm-3 col-form-label">Project background images</label>
    <div class="col-sm-9" style="display:none;">
				<map name="PrimaryProject">
				  <area style="background-color:red;" shape="circle" coords="75,75,75" href="left.html">
				  <area style="background-color:red;" shape="circle" coords="275,75,75" href="right.html">
				</map>
	  <img id="imgPB"  usemap="#PrimaryProject" src="<?php echo $todo_list[0]['ProjectBackgroundImage'];?>" />
    </div>
  </div>
	
	<br>
	
  <div class="img-container" id="imgHotSpot" style="width: 448px;height:218px;background-repeat: no-repeat;margin: 0 auto;">
    <div class="hot-spots" id="DIVhotspots">
	


    </div>
  </div>
  
  <BR>
  
  <div class="MYcontainer" style="display:none;">
    <div class="MYoptions">
        <label>Radius </label><input type="range" id="radius" value="25" min="10" max="50" /><br />
        <label>Blur </label><input type="range" id="blur" value="15" min="10" max="50" />
    </div>
    <canvas id="canvas" width="448" height="218"></canvas>
</div>
  
  <br>
  
  <canvas id="myCanvas" width="448" height="218" style="border:1px solid #d3d3d3;display:none;">
Your browser does not support the HTML5 canvas tag.
</canvas>

	<br>
	
	<div style="text-align: center;">
	  <canvas id="myCanvas7" width="448" height="218" style="border:1px solid #d3d3d3;">
Your browser does not support the HTML5 canvas tag.
</canvas>
<div>
	<br>
	
	<input type="hidden" id="SpaghettiImageB64" name="SpaghettiImageB64" >
	<input type="hidden" id="HeatmapImageB64" name="HeatmapImageB64" >
	
  <div class="form-group row">
    <div class="col-sm-10">
      <button type="submit" class="btn btn-primary">Export</button>
    </div>
  </div>
</form>
			<br>
			<Br>
		  </div>
  </div>
  <div class="col">*</div>
</div>
</div>



    <script type="text/javascript">
	var myArr;
	var data  = new Array();
	var CheckBoxSelected=0;
	var  xUnitScale=<?php echo $todo_list[0]['Unit'];?>;
	
	
	
	//$("#imgHotSpot").css("background-image", "url()");
	document.getElementById("imgHotSpot").style.backgroundImage = "url('<?php echo $todo_list[0]['ProjectBackgroundImage'];?>')"; 
	
	var c = document.getElementById("myCanvas");
    var ctx = c.getContext("2d");
    var img = document.getElementById("imgPB");
	  ctx.drawImage(img, 0, 0);
	  
	  	var d = document.getElementById("canvas");
    var dtx = d.getContext("2d");
    var  cimg = document.getElementById("imgPB");
	  dtx.drawImage(cimg, 0, 0);
	
	let userProjectItems = new Map();
	let dataDeviceIDs = new Map();
	let datesLog = new Map();
	
	
        function encodeLogFileAsURL(element) {
		userProjectItems.clear();
		dataDeviceIDs.clear();
		datesLog.clear();
		
  var file = element.files[0];
  //console.log(file);
  var reader = new FileReader();
  reader.onloadend = function() {

	let str = reader.result;
   myArr = str.split(",");


   for (let i = 0,j = 0; i < myArr.length-29; i+=29,j++) {
	  //console.log(converter.convertToDate(myArr[i]),myArr[i+3],myArr[i+4],myArr[i+5]);
	  const ItemsArr= new Array(converter.convertToDate(myArr[i]), myArr[i+3],myArr[i+4],myArr[i+5]);
	  
		data[j] =new Array(parseFloat(myArr[i+4]*xUnitScale)+224, parseFloat(myArr[i+5]*xUnitScale)+109, 1); //for heatmap
		
	  userProjectItems.set(j, ItemsArr);
	  if (dataDeviceIDs.has("ID"+myArr[i+3])) {} else {dataDeviceIDs.set("ID"+myArr[i+3], myArr[i+3]);}
	  if (datesLog.has(converter.convertToDate(myArr[i]))) {} else {datesLog.set(converter.convertToDate(myArr[i]), converter.convertToDate(myArr[i]));}
	  
	  while ($("#DIVhotspots")[0].firstChild) {
	  $("#DIVhotspots")[0].removeChild($("#DIVhotspots")[0].firstChild)
	  }
	  $("#DIVhotspots").append("<div class=\"hot-spot\" style=\"left:"+myArr[i+4]*xUnitScale+"px;top:"+myArr[i+5]*xUnitScale+"px;\"><div class=\"info\"><h6>DeviceID: " + myArr[i+3] + "</h6><p>X: "+myArr[i+4]*xUnitScale+"<br> Y: "+myArr[i+5]*xUnitScale+"</p><p>Date: " + converter.convertToDate(myArr[i]) + "</p></div></div>"); 
	  
	 
	  
	  //$("#DIVhotspots").append('<label>Reached the limit</label>'); 
	}
	
	for (let VL  of dataDeviceIDs.values()) {
  		  $("#chkSelectDevices").append("<div class=\"form-check form-check-inline\"><input class=\"form-check-input\" type=\"checkbox\" onchange=\"(checkBoxClicked(this))\" name=\"ExportSelectionType\" id=\"Device"+VL+"\" value=\""+VL+"\"><label class=\"form-check-label\" for=\"Heatmap\">"+VL+"</label></div>"); 
}

	for (let VLDate  of datesLog.values()) {
          const myArrs = VLDate.split(" ");
  		  $("#DateFrom").append("<option value="+myArrs[0]+ myArrs[1]+ ":" +myArrs[2]+">"+VLDate+"</option>"); 
		  $("#DateTo").append("<option value="+myArrs[0]+ myArrs[1]+ ":" +myArrs[2]+">"+VLDate+"</option>"); 
	}
	
	draw();
	document.getElementById("FileRead").value=reader.result;
	
	
		var c = document.getElementById("myCanvas7");
    var ctx = c.getContext("2d");
	ctx.globalCompositeOperation = 'multiply';
    var img = document.getElementById("imgPB");
	  ctx.drawImage(img, 0, 0);
	  

    var  cimg = document.getElementById("canvas");
	  ctx.drawImage(cimg, 0, 0);
	
  }
  reader.readAsText(file);
}
    </script>
	
	<script type="text/javascript">
	
	$(".ChangeByItemSelection").change(function(){
	

    //var from = new Date(converter.convertToDate(myArr[0]));  // -1 because months are from 0 to 11
	//var to   = new Date(converter.convertToDate(myArr[myArr.length-30].replace("\r", "").replace("\n", "")));
	//var check = new Date($(this).val());
	
	var from = new Date($("#DateFrom").val());  // -1 because months are from 0 to 11
	var to   = new Date($("#DateTo").val());
	var check = new Date($(this).val());
	
		console.log(from);
		console.log(to);
		console.log(check);
	
			  while ($("#DIVhotspots")[0].firstChild) {
	  $("#DIVhotspots")[0].removeChild($("#DIVhotspots")[0].firstChild)
	  }
	  
	data=[];
   for (let i = 0,j = 0; i < myArr.length-29; i+=29,j++) {
        check="";
		check = new Date(converter.convertToDate(myArr[i].replace("\r", "").replace("\n", "")));
		if (check >= from && check <= to && myArr[i+3]==CheckBoxSelected){
			data[j] =new Array(parseFloat(myArr[i+4]*xUnitScale)+224, parseFloat(myArr[i+5]*xUnitScale)+109, 1); //for heatmap
			
	  $("#DIVhotspots").append("<div class=\"hot-spot\" style=\"left:"+myArr[i+4]*xUnitScale+"px;top:"+myArr[i+5]*xUnitScale+"px;\"><div class=\"info\"><h6>DeviceID: " + myArr[i+3] + "</h6><p>X: "+myArr[i+4]*xUnitScale+"<br> Y: "+myArr[i+5]*xUnitScale+"</p><p>Date: " + converter.convertToDate(myArr[i]) + "</p></div></div>"); 
	  
		}
		
	}
	

	  
		draw();

	
		var c = document.getElementById("myCanvas7");
    var ctx = c.getContext("2d");
	ctx.clearRect(0, 0, 448, 218);
	ctx.globalCompositeOperation = 'multiply';
    var img = document.getElementById("imgPB");
	  ctx.drawImage(img, 0, 0);
	  

    var  cimg = document.getElementById("canvas");
	  ctx.drawImage(cimg, 0, 0);
encodeImageFileTOURL(c);

});

 function checkBoxClicked(Control){
  CheckBoxSelected=Control.value;
  $("#SelectDevices").val(Control.value);
 }

	</script>
	
		<script type="text/javascript">
		
		var converter = {
			
			epochInterval : null,
			
			epochIntervalMs: null,			
			
			epoch: function() {
				$('#epoch').text(parseInt(new Date().getTime() / 1000));
			},
			
			epochMs: function() {
				$('#epochMs').text(parseInt(new Date().getTime()));
			},
			
			startEpoch: function() {
				if (converter.epochInterval == null) {
					converter.epochInterval = setInterval('converter.epoch()', 750);
				}
			},
			
			startEpochMs: function() {
				if (converter.epochIntervalMs == null) {
					converter.epochIntervalMs = setInterval('converter.epochMs()', 257);
				}
			},			
			
			stopEpoch: function() {
				if (converter.epochInterval != null) {
					clearInterval(converter.epochInterval);
					converter.epochInterval = null;
				}
			},
			
			stopEpochMs: function() {
				if (converter.epochIntervalMs != null) {
					clearInterval(converter.epochIntervalMs);
					converter.epochIntervalMs = null;
				}
			},
			
			convertToDate: function(TT) {

				var sourceEpoch = TT;
				sourceEpoch = parseInt(sourceEpoch);

				if (isNaN(sourceEpoch)) {
					return 'Invalid Timestamp';
				} else {
					if (sourceEpoch <= 9999999999) {
						sourceEpoch *= 1000;
					}
					var date = new Date(sourceEpoch);
					return date.toLocaleString();
				}
				
			},
			
			getValue: function(id) {
				var value = $('#' + id).val();
				value = value.replace(/^0*([0-9]+)$/, '$1');
				return parseInt(value);
			}, 
			
			convertToEpoch: function() {

				var d = null;
				if ($('#timeZone').val() == 'gmt') {
					d = new Date(Date.UTC(
						converter.getValue('year'), 
						(converter.getValue('month') - 1),
						converter.getValue('date'),
						converter.getValue('hours'),
						converter.getValue('minutes'),
						converter.getValue('seconds')
					));
				} else {
					d = new Date(
						converter.getValue('year'), 
						(converter.getValue('month') - 1),
						converter.getValue('date'),
						converter.getValue('hours'),
						converter.getValue('minutes'),
						converter.getValue('seconds')
					);					
				}
				
				$('#resultEpoch').text(parseInt(d.getTime() / 1000));
				$('#result').show();
			
			}
			
		};		
		
	</script>	
 
 
 <script src="<?php echo base_url('assets/js/simpleheat.js');?>" type="text/javascript"></script>
 
 <script>

window.requestAnimationFrame = window.requestAnimationFrame || window.mozRequestAnimationFrame ||
                               window.webkitRequestAnimationFrame || window.msRequestAnimationFrame;

function get(id) {
    return document.getElementById(id);
}

var heat = simpleheat('canvas').data(data).max(18),
    frame;

function draw() {
    console.time('draw');
    heat.draw();
    console.timeEnd('draw');
    frame = null;
}

draw();


var radius = get('radius'),
    blur = get('blur'),
    changeType = 'oninput' in radius ? 'oninput' : 'onchange';

radius[changeType] = blur[changeType] = function (e) {
    heat.radius(+radius.value, +blur.value);
    frame = frame || window.requestAnimationFrame(draw);
};

</script>

    <script type="text/javascript">
        function encodeImageFileTOURL(element) {
        const canvasB64 = document.createElement('canvas');
        const ctx = canvasB64.getContext('2d');
        let dataURL;
        canvasB64.height = 488;
        canvasB64.width = 218;
        ctx.drawImage(element, 0, 0);
        dataURL = canvasB64.toDataURL("image/jpeg");
	document.getElementById("HeatmapImageB64").value=dataURL;
	document.getElementById("SpaghettiImageB64").value=dataURL;

  }

    </script>
