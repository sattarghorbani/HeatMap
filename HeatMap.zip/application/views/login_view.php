  
  <div class="container-fluid">
  <h2></h2>
  <p></p>
  <div class="row">
    <div class="col-3"> </div>
    <div class="col-6">
         <form class="form-signin" action="<?php echo site_url('login/auth');?>" method="post">
           <h2 class="form-signin-heading">Please sign in</h2>
           <?php echo $this->session->flashdata('msg');?>
           <label for="username" class="sr-only">Username</label>
           <input type="email" name="email" class="form-control" placeholder="Email" required autofocus>
           <label for="password" class="sr-only">Password</label>
           <input type="password" name="password" class="form-control" placeholder="Password" required>
           <div class="checkbox">
             <label>
               <input type="checkbox" value="remember-me"> Remember me
             </label>
           </div>
           <button class="btn btn-lg btn-primary btn-block" type="submit">Sign in</button>
         </form>
	</div>
    <div class="col-3"> </div>
  </div>
</div>
 
 
   <div class="text-center">
    <p>Not a member? <a href="<?php echo site_url('Register');?>">Register</a></p>
    <p>or sign up with:</p>
    <button type="button" class="btn btn-primary btn-floating mx-1">
      <i class="fa fa-facebook"></i>
    </button>

    <button type="button" class="btn btn-primary btn-floating mx-1">
      <i class="fa fa-google"></i>
    </button>

    <button type="button" class="btn btn-primary btn-floating mx-1">
      <i class="fa fa-twitter"></i>
    </button>

    <button type="button" class="btn btn-primary btn-floating mx-1">
      <i class="fa fa-github"></i>
    </button>
  </div>
 
 