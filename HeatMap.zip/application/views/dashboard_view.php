
    <div class="container">
      <div class="row">
	  
		<nav class="navbar navbar-expand-md bg-dark navbar-dark">
		  <a class="navbar-brand" href="#">Welcome  <?php echo $this->session->userdata('username');?></a>
		  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
		    <span class="navbar-toggler-icon"></span>
		  </button>
		  <div class="collapse navbar-collapse" id="collapsibleNavbar">
		
              <ul class="navbar-nav">
                <!--ACCESS MENUS FOR ADMIN-->
                <?php if($this->session->userdata('level')==='1'):?>
                  <li class="nav-item"><a class="nav-link" href="<?php echo site_url('page');?>">Dashboard</a></li>
                  <li class="nav-item"></li>
									      <!-- Dropdown -->
					    <li class="nav-item dropdown">
					      <a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">
					        Projects
					      </a>
					      <div class="dropdown-menu">
					        <a class="dropdown-item" href="<?php echo site_url('AddProject');?>">Add Project</a>
					        <a class="dropdown-item" href="<?php echo site_url('ListProject');?>">List Project</a>
					      </div>
					    </li>
                  <li class="nav-item"><a class="nav-link" href="<?php echo site_url('CompanyInfo');?>">Company Info</a></li>
                <!--ACCESS MENUS FOR STAFF-->
                <?php elseif($this->session->userdata('level')==='2'):?>
                  <li class="nav-item"><a class="nav-link" href="<?php echo site_url('page');?>">Dashboard</a></li>
                  <li class="nav-item"><a class="nav-link" href="<?php echo site_url('CompanyInfo');?>">Company Info</a></li>
                <!--ACCESS MENUS FOR AUTHOR-->
                <?php else:?>
                  <li class="nav-item"><a class="nav-link" href="<?php echo site_url('page');?>">Dashboard</a></li>
                  <li class="nav-item"><a class="nav-link" href="#">Posts</a></li>
                <?php endif;?>
              </ul>
			
			  <ul class="navbar-nav navbar-right">
                <li><a class="nav-link" href="<?php echo site_url('login/logout');?>">Sign Out</a></li>
              </ul>
		  </div>  
		</nav>
	  

      </div>
    </div>
 

