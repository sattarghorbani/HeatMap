<?php
class EditProject extends CI_Controller{
  function __construct(){
    parent::__construct();
    if($this->session->userdata('logged_in') !== TRUE){
	 
      redirect('login');
    }
  }
  

  function Edit(){
      if($this->session->userdata('level')==='1'){
		$this->load->model('Projects_model');
		  $userid=$this->session->userdata('userid');
		  $Projectid=$this->input->post_get('Projectid', TRUE);
		  $ProjectTitle=$this->input->post_get('ProjectTitle', TRUE);
		  $ProjectDevices=$this->input->post_get('ProjectDevices', TRUE);
		  $ProjectDevicesColor=$this->input->post_get('ProjectDevicesColor', TRUE);
		  $ProjectDeviceType=$this->input->post_get('ProjectDeviceType', TRUE);
		  $ProjectUnit=$this->input->post_get('ProjectUnit', TRUE);
		  $ImageFile=$this->input->post_get('ImageFileB64', FALSE);

		  $this->Projects_model->Update($Projectid,$userid,$ProjectTitle,$ProjectDevices,$ProjectDevicesColor,$ProjectDeviceType,$ProjectUnit,$ImageFile);
		  
		  redirect('ListProject');// "Success";
      }else{
          echo "Access Denied";
      }
  }
  
    function index(int $ProjectID){
    //Allowing akses to admin only
      if($this->session->userdata('level')==='1'){
	  $this->load->model('Projects_model');
	  $userid=$this->session->userdata('userid');
	  $result= $this->Projects_model->ProjectListByID($ProjectID,$userid);
	  $rows = array(); //will hold all results
	
	foreach ($result->result_array() as $row)
{
		$rows[] = $row;
}
	  
	  
	  	  $data['todo_list'] = $rows;
		  $this->load->view('TopPage_view');
		  $this->load->view('dashboard_view');
          $this->load->view('EditProject_view', $data);
		  $this->load->view('BottomPage_view');
      }else{
          echo "Access Denied";
      }
 
  }
  
  }

?>