<?php
class ViewProject extends CI_Controller{
  function __construct(){
    parent::__construct();
    if($this->session->userdata('logged_in') !== TRUE){
      redirect('login');
    }
  }
  
  
    function index(int $ProjectID){
    //Allowing akses to admin only
      if($this->session->userdata('level')==='1'){
	  $this->load->model('Projects_model');
	  $userid=$this->session->userdata('userid');
	  $result= $this->Projects_model->ProjectListByID($ProjectID,$userid);
	  $rows = array(); //will hold all results
	
	foreach ($result->result_array() as $row)
{
		$rows[] = $row;
}
	  
	  
	  	  $data['todo_list'] = $rows;
		  $this->load->view('TopPage_view');
		  $this->load->view('dashboard_view');
          $this->load->view('ViewProject_view', $data);
		  $this->load->view('BottomPage_view');
      }else{
          echo "Access Denied";
      }
 
  }
  
  }

?>