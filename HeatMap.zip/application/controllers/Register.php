<?php
class Register extends CI_Controller{
  function __construct(){
    parent::__construct();
    //if($this->session->userdata('logged_in') !== TRUE){
    //  redirect('login');
    //}
	$this->load->model('Account_model');
	//$this->session->set_flashdata('RegisterationMsg','');
  }
 
  function index(){
    //Allowing akses to admin only
      //if($this->session->userdata('level')==='1'){ 
	  
		  $this->load->view('TopPage_view');
		  //$this->load->view('dashboard_view');
          $this->load->view('Register_view');
		  $this->load->view('BottomPage_view');
     // }else{
      //    echo "Access Denied";
     // }
 
  }
    
    function SaveNewMember(){
	$FirstName    = $this->input->post('FirstName',TRUE);
    $LastName = $this->input->post('LastName',TRUE);
	$Company = $this->input->post('Company',TRUE);
	$Gender =$this->input->post('gender',TRUE);
    $email    = $this->input->post('email',TRUE);
	$City =$this->input->post('City',TRUE);
    $Country    = $this->input->post('Country',TRUE);
	$UserName    = $this->input->post('username',TRUE);
    $password = md5($this->input->post('password',TRUE));
	
	 $validate = $this->Account_model->validate($UserName);

    if($validate->num_rows() <= 0){
       $this->Account_model->Insert($FirstName,$LastName,$Company,$Gender,$email,$City,$Country,$UserName,$password);
	   echo $this->session->set_flashdata('RegisterationMsg','Success, now login.');
		redirect('Register');
    }else{
		echo $this->session->set_flashdata('RegisterationMsg','Error ! this account is already registered !. please login');
		redirect('Register');
    }


  }
 
 
}

?>