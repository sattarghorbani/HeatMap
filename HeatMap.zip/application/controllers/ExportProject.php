<?php
class ExportProject extends CI_Controller{
  function __construct(){
    parent::__construct();
    if($this->session->userdata('logged_in') !== TRUE){
      redirect('login');
    }
  }
 
  function index(int $ProjectID){
    //Allowing akses to admin only
      if($this->session->userdata('level')==='1'){
	  $this->load->model('Projects_model');
	  $userid=$this->session->userdata('userid');
	  $result= $this->Projects_model->ProjectListByID($ProjectID,$userid);
	  $rows = array(); //will hold all results
	
	foreach ($result->result_array() as $row)
{
		$rows[] = $row;
}
	  
	  
	  	  $data['todo_list'] = $rows;
		  $this->load->view('TopPage_view');
		  $this->load->view('dashboard_view');
          $this->load->view('ExportProject_view', $data);
		  $this->load->view('BottomPage_view');
      }else{
          echo "Access Denied";
      }
 
  }
  
    function SaveNewExport(){
    //Allowing akses to admin only
      if($this->session->userdata('level')==='1'){
		  $this->load->model('Projects_model');
		  
		  $User_id=$this->session->userdata('userid');
		  $ProjectID=$this->input->post_get('ProjectID', TRUE);
		  $DateTimeFrom=$this->input->post_get('DateFrom', FALSE);
		  $DateTimeTo=$this->input->post_get('DateTo', FALSE);
		  $SelectDevices=$this->input->post_get('SelectDevices', TRUE);
		  $SelectType=$this->input->post_get('ExportSelectionType', TRUE);
		  $SpaghettiImage=$this->input->post_get('SpaghettiImageB64', FALSE);
		  $HeatmapImage=$this->input->post_get('HeatmapImageB64', FALSE);
		  $LogFile=$this->input->post_get('LogFile', FALSE);

		  $this->Projects_model->InsertExportProject($ProjectID,$User_id,$DateTimeFrom,$DateTimeTo,$SelectDevices,$SelectType,$SpaghettiImage,$HeatmapImage,$LogFile);
		  
		  redirect('ListProject');// "Success";
      }else{
          echo "Access Denied";
      }
 
  }
 
 
}

?>