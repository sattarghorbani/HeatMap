<?php
class AddProject extends CI_Controller{
  function __construct(){
    parent::__construct();
    if($this->session->userdata('logged_in') !== TRUE){
      redirect('login');
    }
  }
 
  function index(){
    //Allowing akses to admin only
      if($this->session->userdata('level')==='1'){
		  $this->load->view('TopPage_view');
		  $this->load->view('dashboard_view');
          $this->load->view('AddProject_view');
		  $this->load->view('BottomPage_view');
      }else{
          echo "Access Denied";
      }
 
  }
  
    function SaveNewProject(){
    //Allowing akses to admin only
      if($this->session->userdata('level')==='1'){
		  $this->load->model('Projects_model');
		  
		  $userid=$this->session->userdata('userid');
		  $ProjectTitle=$this->input->post_get('ProjectTitle', TRUE);
		  $ProjectDevices=$this->input->post_get('ProjectDevices', TRUE);
		  $ProjectDevicesColor=$this->input->post_get('ProjectDevicesColor', TRUE);
		  $ProjectDeviceType=$this->input->post_get('ProjectDeviceType', TRUE);
		  $ProjectUnit=$this->input->post_get('ProjectUnit', TRUE);
		  $ImageFile=$this->input->post_get('ImageFileB64', FALSE);

		  $this->Projects_model->Insert($userid,$ProjectTitle,$ProjectDevices,$ProjectDevicesColor,$ProjectDeviceType,$ProjectUnit,$ImageFile);
		  
		  redirect('ListProject');// "Success";
      }else{
          echo "Access Denied";
      }
 
  }
 
 
}

?>