<?php
class Account_model extends CI_Model{
 
  function validate($userName){
    //$this->db->where('user_email',$email);
    $this->db->where('user_name',$userName);
    $result = $this->db->get('tbl_users',1);
    return $result;
  }
  
    function UserInfo($UserID){
	$this->db->select('*');
	$this->db->from('tbl_users');
	//$this->db->join('tbl_users', 'tbl_users.user_id = projects.User_id');
	$this->db->where('user_id',$UserID);
	$query = $this->db->get();
    return $query;
  }
  
   function GetAllUsers(){
	$this->db->select('*');
	$this->db->from('tbl_users');
	$query = $this->db->get();
    return $query;
  }
  
  function Delete($UserID){
    $this->db->where('user_id',$UserID);
    $result = $this->db->delete('tbl_users');
    return $result;
  }
  
    function Insert($FirstName,$LastName,$Company,$Gender,$email,$City,$Country,$UserName,$password){
	$data = array(
	        'FirstName' => $FirstName,
	        'LastName' => $LastName,
	        'CompanyName' => $Company,
			'Gender' => $Gender,
			'user_email' => $email,
			'City' => $City,
			'Country' => $Country,
			'user_name' => $UserName,
			'user_password' => $password,
			'user_level' => 1,
	);
	$result = $this->db->insert('tbl_users', $data);
   return $result;
   
  }
  
      function Update($FirstName,$LastName,$Company,$Gender,$email,$City,$Country,$UserName,$password,$user_level){
	$data = array(
	        'FirstName' => $FirstName,
	        'LastName' => $LastName,
	        'CompanyName' => $Company,
			'Gender' => $Gender,
			'user_email' => $email,
			'City' => $City,
			'Country' => $Country,
			'user_name' => $UserName,
			'user_password' => $password,
			'user_level' => $user_level
	);
	$this->db->where('user_id',$UserID);
    $result = $this->db->update('tbl_users', $data);
    return $result;
  }
 
}

?>