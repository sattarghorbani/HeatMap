<?php
class Projects_model extends CI_Model{
 
  function validate($ProjectID){
    $this->db->where('ProjectID',$ProjectID);
    $result = $this->db->get('projects',1);
    return $result;
  }
  
    function ProjectList($UserID){
	$this->db->select('*');
	$this->db->from('projects');
	$this->db->join('tbl_users', 'tbl_users.user_id = projects.User_id');
	$this->db->where('projects.User_id',$UserID);
	$query = $this->db->get();
    return $query;
  }
  
   function ProjectListByID($ProjectID,$UserID){
	$this->db->select('*');
	$this->db->from('projects');
	$this->db->join('tbl_users', 'tbl_users.user_id = projects.User_id');
	$this->db->where('projects.ProjectID',$ProjectID);
	$this->db->where('projects.User_id',$UserID);
	$query = $this->db->get();
    return $query;
  }
  
     function ProjectListWithExpoByID($ProjectID,$UserID){
	$this->db->select('*');
	$this->db->from('projects');
	$this->db->join('tbl_users', 'tbl_users.user_id = projects.User_id');
	$this->db->join('projectsexports', 'tbl_users.user_id = projectsexports.User_id AND projectsexports.ProjectID = projects.ProjectID');
	$this->db->where('projects.ProjectID',$ProjectID);
	$this->db->where('projects.User_id',$UserID);
	$query = $this->db->get();
    return $query;
  }
  
  function Delete($ProjectID){
    $this->db->where('ProjectID',$ProjectID);
    $result = $this->db->delete('projects');
    return $result;
  }
  
    function Insert($User_id,$ProjectTitle,$ProjectDeviceID,$ProjectDeviceColor,$ProjectDeviceType,$Unit,$ProjectBackgroundImage){
	$data = array(
	        'User_id' => $User_id,
	        'ProjectTitle' => $ProjectTitle,
	        'ProjectDeviceID' => $ProjectDeviceID,
			'ProjectDeviceColor' => $ProjectDeviceColor,
			'ProjectDeviceType' => $ProjectDeviceType,
			'Unit' => $Unit,
			'ProjectBackgroundImage' => $ProjectBackgroundImage
	);
    $result = $this->db->insert('projects', $data);
    return $result;
  }
  
      function InsertExportProject($ProjectID,$User_id,$DateTimeFrom,$DateTimeTo,$SelectDevices,$SelectType,$SpaghettiImage,$HeatmapImage,$LogFile){
	$data = array(
	        'ProjectID' => $ProjectID,
	        'User_id' => $User_id,
	        'DateTimeFrom' => $DateTimeFrom,
			'DateTimeTo' => $DateTimeTo,
			'SelectDevices' => $SelectDevices,
			'SelectType' => $SelectType,
			'SpaghettiImage' => $SpaghettiImage,
			'HeatmapImage' => $HeatmapImage,
			'LogFile' => $LogFile
	);
    $result = $this->db->insert('projectsexports', $data);
    return $result;
  }
  
      function Update($ProjectID,$User_id,$ProjectTitle,$ProjectDeviceID,$ProjectDeviceColor,$ProjectDeviceType,$Unit,$ProjectBackgroundImage){
	$data = array(
	        'User_id' => $User_id,
	        'ProjectTitle' => $ProjectTitle,
	        'ProjectDeviceID' => $ProjectDeviceID,
			'ProjectDeviceColor' => $ProjectDeviceColor,
			'ProjectDeviceType' => $ProjectDeviceType,
			'Unit' => $Unit,
			'ProjectBackgroundImage' => $ProjectBackgroundImage
	);
	$this->db->where('ProjectID',$ProjectID);
    $result = $this->db->update('projects', $data);

    return $result;
  }
 
}

?>