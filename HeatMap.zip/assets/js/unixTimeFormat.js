	<script type="text/javascript">
		
		var converter = {
			
			epochInterval : null,
			
			epochIntervalMs: null,			
			
			epoch: function() {
				$('#epoch').text(parseInt(new Date().getTime() / 1000));
			},
			
			epochMs: function() {
				$('#epochMs').text(parseInt(new Date().getTime()));
			},
			
			startEpoch: function() {
				if (converter.epochInterval == null) {
					converter.epochInterval = setInterval('converter.epoch()', 750);
				}
			},
			
			startEpochMs: function() {
				if (converter.epochIntervalMs == null) {
					converter.epochIntervalMs = setInterval('converter.epochMs()', 257);
				}
			},			
			
			stopEpoch: function() {
				if (converter.epochInterval != null) {
					clearInterval(converter.epochInterval);
					converter.epochInterval = null;
				}
			},
			
			stopEpochMs: function() {
				if (converter.epochIntervalMs != null) {
					clearInterval(converter.epochIntervalMs);
					converter.epochIntervalMs = null;
				}
			},
			
			convertToDate: function(TT) {

				var sourceEpoch = TT;
				sourceEpoch = parseInt(sourceEpoch);

				if (isNaN(sourceEpoch)) {
					return 'Invalid Timestamp';
				} else {
					if (sourceEpoch <= 9999999999) {
						sourceEpoch *= 1000;
					}
					var date = new Date(sourceEpoch);
					return date.toLocaleString();
				}
				
			},
			
			getValue: function(id) {
				var value = $('#' + id).val();
				value = value.replace(/^0*([0-9]+)$/, '$1');
				return parseInt(value);
			}, 
			
			convertToEpoch: function() {

				var d = null;
				if ($('#timeZone').val() == 'gmt') {
					d = new Date(Date.UTC(
						converter.getValue('year'), 
						(converter.getValue('month') - 1),
						converter.getValue('date'),
						converter.getValue('hours'),
						converter.getValue('minutes'),
						converter.getValue('seconds')
					));
				} else {
					d = new Date(
						converter.getValue('year'), 
						(converter.getValue('month') - 1),
						converter.getValue('date'),
						converter.getValue('hours'),
						converter.getValue('minutes'),
						converter.getValue('seconds')
					);					
				}
				
				$('#resultEpoch').text(parseInt(d.getTime() / 1000));
				$('#result').show();
			
			}
			
		};		
		
	</script>	